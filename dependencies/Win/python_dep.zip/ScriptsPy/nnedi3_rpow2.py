def nnedi3_rpow2(clip,rfactor,correct_shift="fmtconv",nsize=0,nns=3,qual=None,etype=None,pscrn=None,opt=None,fapprox=None):
	import vapoursynth as vs
	import math
	core = vs.get_core()
	
	if int(rfactor/2)*2!=rfactor:
		raise ValueError('nnedi3_rpow2 : rfactor must be a power of two')
	
	steps=int(math.log(rfactor)/math.log(2)) # 2^steps=rfactor
	
	clip=core.std.Transpose(clip)
	for i in range(0,steps):
		clip=core.nnedi3.nnedi3(clip=clip,field=1,dh=1,nsize=nsize,nns=nns,qual=qual,etype=etype,pscrn=pscrn,opt=opt,fapprox=fapprox)
	clip=core.std.Transpose(clip)
	clip=core.nnedi3.nnedi3(clip=clip,field=1,dh=1,nsize=nsize,nns=nns,qual=qual,etype=etype,pscrn=pscrn,opt=opt,fapprox=fapprox)
	for i in range(0,steps-1):
		clip=core.nnedi3.nnedi3(clip=clip,field=0,dh=1,nsize=nsize,nns=nns,qual=qual,etype=etype,pscrn=pscrn,opt=opt,fapprox=fapprox)
	
	if correct_shift=="fmtconv" or correct_shift=="zimgv1":
		depth=clip.format.bits_per_sample
		if clip.format.subsampling_w==1:
			hshift=-rfactor/2+0.5 # hshift(steps+1)=2*hshift(steps)-0.5
		else :
			hshift=-0.5
	
	if correct_shift=="fmtconv":
		if clip.format.subsampling_h==0:
			clip=core.fmtc.resample(clip=clip,sx=hshift,sy=-0.5)
		else :
			clip=core.fmtc.resample(clip=clip,sx=hshift,sy=-0.5,planes=[3,2,2])
			clip=core.fmtc.resample(clip=clip,sx=hshift,sy=-1,planes=[2,3,3])
		if depth!=16:
			clip=core.fmtc.bitdepth(clip=clip,bits=depth)
	
	if correct_shift=="zimgv1":
		if depth!=16:
			clip=core.z.Depth(clip=clip,depth=16,dither="error_diffusion")
		if clip.format.subsampling_h==0:
			clip=core.z.Resize(clip=clip,filter="spline36",width=clip.width,height=clip.height,shift_w=hshift,shift_h=-0.5)
		else :
			Y=core.std.ShufflePlanes(clips=clip, planes=0, colorfamily=vs.GRAY)
			U=core.std.ShufflePlanes(clips=clip, planes=1, colorfamily=vs.GRAY)
			V=core.std.ShufflePlanes(clips=clip, planes=2, colorfamily=vs.GRAY)
			Y=core.z.Resize(clip=Y,filter="spline36",width=clip.width,height=clip.height,shift_w=hshift,shift_h=-0.5)
			U=core.z.Resize(clip=U,filter="spline36",width=clip.width,height=clip.height,shift_w=hshift/2,shift_h=-0.5)
			V=core.z.Resize(clip=V,filter="spline36",width=clip.width,height=clip.height,shift_w=hshift/2,shift_h=-0.5)
			clip=core.std.ShufflePlanes(clips=[Y,U,V], planes=[0,0,0], colorfamily=vs.YUV)
		if depth!=16:
			clip=core.z.Depth(clip=clip,depth=depth,dither="error_diffusion")
	
	return clip
